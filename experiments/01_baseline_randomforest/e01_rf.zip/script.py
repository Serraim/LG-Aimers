"""
평가 서버에서 실행되는 추론 코드
=================================

제출 시 이 파일이 submit.zip의 script.py 로 들어간다.
평가 서버가 `python script.py` 로 직접 실행한다.

디렉토리 구조 (평가 서버 기준)
------------------------------
    ./model/                모델 artifact (참가자 제출)
    ./script.py             이 파일     (참가자 제출)
    ./requirements.txt      패키지      (참가자 제출)
    ./data/test.csv         평가 데이터 (서버가 제공, 읽기 전용)
    ./data/sample_submission.csv
    ./output/submission.csv 결과 (이 코드가 생성)

대회 규칙 (AGENTS.md §2)
------------------------
    평가 데이터의 각 행은 독립적으로 예측되어야 한다.
    이 파일에서는 test 전체를 대상으로 하는 집계
    (groupby / mean / rolling / rank ...)를 사용하지 않는다.

    train 기반 통계는 학습 단계에서 계산해 artifact 에 저장하고,
    여기서는 현재 행의 값으로 lookup 만 수행한다. (AGENTS.md §5)

    검증: python scripts/check_rules.py --submit-dir <폴더>

check_rules.py 연동
-------------------
    predict_control_success(test) 를 제공한다.
    검사기가 이 함수를 찾아 "전체 입력" 과 "한 행씩 입력" 의 결과를 대조한다.
"""

import glob
import os

import joblib
import numpy as np
import pandas as pd

ID_COL = "row_id"
TARGET_COL = "control_success"

MODEL_DIR = "./model"
TEST_DIR = "./data"
OUT_PATH = "./output/submission.csv"


# ============================================================
# 모델 artifact
# ============================================================

_ARTIFACT_CACHE = None


def find_model_file(model_dir=MODEL_DIR):
    for ext in ("*.joblib", "*.pkl"):
        hits = sorted(glob.glob(os.path.join(model_dir, ext)))
        if hits:
            return hits[0]
    raise FileNotFoundError(f"{model_dir} 안에 모델 파일(.joblib/.pkl)이 없음")


def load_artifact(model_dir=MODEL_DIR):
    """모델을 한 번만 읽어 재사용한다."""
    global _ARTIFACT_CACHE
    if _ARTIFACT_CACHE is None:
        _ARTIFACT_CACHE = joblib.load(find_model_file(model_dir))
    return _ARTIFACT_CACHE


# ============================================================
# 데이터 로드
# ============================================================

def load_test(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if ID_COL not in df.columns:
        raise ValueError(f"test 데이터에 {ID_COL} 컬럼이 없음: {list(df.columns)[:5]}")
    return df


def load_sample_submission(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if list(df.columns[:2]) != [ID_COL, TARGET_COL]:
        raise ValueError(
            f"sample_submission 컬럼이 ({ID_COL}, {TARGET_COL})이 아님: {list(df.columns)}")
    return df


# ============================================================
# 전처리 - 학습과 반드시 동일해야 함
# ============================================================

def build_features(df, artifact=None):
    """모델 입력 생성. 행 단위 연산만 사용한다.

    artifact 가 None 이면 (sklearn Pipeline 형식):
        row_id 만 제외하고 반환. 전처리는 Pipeline 내부에서 수행된다.

    artifact 가 dict 이면 (artifact 형식):
        저장된 컬럼 순서로 정렬하고 범주형을 학습 때의 코드로 변환한다.
        변환 표는 train 으로 만들어 저장된 것이며 test 를 보고 만들지 않는다.
    """
    if artifact is None:
        return df.drop(columns=[ID_COL])

    features = artifact["features"]
    cat_cols = artifact.get("cat_cols", [])
    cat_maps = artifact.get("cat_maps", {})

    X = df[features].copy()
    for col in cat_cols:
        mapping = cat_maps[col]                     # train 에서 만든 고정 표
        X[col] = X[col].map(mapping)                # 행 단위 lookup
        X[col] = X[col].fillna(-1).astype("int32")  # 학습 때 못 본 값은 -1
    return X


# ============================================================
# 추론
# ============================================================

def _predict_values(artifact, X):
    """제구 성공(1) 확률. 0~1 범위를 보장한다."""
    if len(X) == 0:
        return np.array([])

    if isinstance(artifact, dict):
        model = artifact["model"]
        kind = artifact.get("kind", "proba")
    else:
        model, kind = artifact, "proba"

    if kind == "proba":
        values = model.predict_proba(X)[:, 1]
    else:
        # 회귀 모델(L2 = Brier 직접 최적화)은 범위를 벗어날 수 있다
        values = model.predict(X)

    return np.clip(values, 0.0, 1.0)


def predict_control_success(test):
    """test 데이터프레임을 받아 제구 성공 확률 배열을 반환한다.

    각 행은 독립적으로 계산된다.
    한 행만 넣어도, 전체를 넣어도 같은 값이 나온다.
    """
    artifact = load_artifact()
    X = build_features(test, artifact if isinstance(artifact, dict) else None)
    return _predict_values(artifact, X)


# ============================================================
# 제출 파일 생성
# ============================================================

def merge_predictions(sub, ids, preds):
    """sample_submission 의 row_id 순서에 맞춰 예측값을 채운다."""
    pred_map = dict(zip(ids, preds))
    values, n_missing = [], 0
    for rid, cur in zip(sub[ID_COL], sub[TARGET_COL]):
        p = pred_map.get(rid)
        if p is None:
            n_missing += 1
            values.append(cur)
        else:
            values.append(p)
    if n_missing:
        print(f"  경고: 예측이 없어 placeholder 를 유지한 row_id {n_missing}건")
    sub[TARGET_COL] = values
    return sub


def save_submission(path, sub):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sub.to_csv(path, index=False, encoding="utf-8")


# ============================================================

def main():
    print("Load model...")
    artifact = load_artifact()
    kind = "artifact" if isinstance(artifact, dict) else "sklearn pipeline"
    print(f"  {os.path.basename(find_model_file())} ({kind})")

    print("Load test data...")
    test = load_test(os.path.join(TEST_DIR, "test.csv"))
    sub = load_sample_submission(os.path.join(TEST_DIR, "sample_submission.csv"))
    print(f"  test={len(test)}  submission={len(sub)}")

    print("Inference...")
    ids = test[ID_COL].tolist()
    preds = predict_control_success(test)
    print(f"  preds={len(preds)}")

    print("Build submission...")
    sub = merge_predictions(sub, ids, preds)
    save_submission(OUT_PATH, sub)
    print(f"Saved: {OUT_PATH} (rows={len(sub)})")


if __name__ == "__main__":
    main()
