"""
평가 서버에서 실행되는 추론 코드
=================================

제출 시 이 파일이 submit.zip의 script.py 로 들어간다.
평가 서버가 `python script.py` 로 직접 실행한다.

디렉토리 구조 (평가 서버 기준)
------------------------------
    ./model/                모델 artifact (참가자 제출)
    ./script.py             이 파일     (참가자 제출)
    ./requirements.txt      패키지      (참가자 제출)
    ./data/test.csv         평가 데이터 (서버가 제공, 읽기 전용)
    ./data/sample_submission.csv
    ./output/submission.csv 결과 (이 코드가 생성)

대회 규칙 (AGENTS.md §2)
------------------------
    평가 데이터의 각 행은 독립적으로 예측되어야 한다.
    이 파일에서는 test 전체를 대상으로 하는 집계
    (groupby / mean / rolling / rank ...)를 사용하지 않는다.

    train 기반 통계는 학습 단계에서 계산해 artifact 에 저장하고,
    여기서는 현재 행의 값으로 lookup 만 수행한다. (AGENTS.md §5)

    검증: python scripts/check_rules.py --submit-dir <폴더>

check_rules.py 연동
-------------------
    predict_control_success(test) 를 제공한다.
    검사기가 이 함수를 찾아 "전체 입력" 과 "한 행씩 입력" 의 결과를 대조한다.
"""

import glob
import os

import joblib
import numpy as np
import pandas as pd

ID_COL = "row_id"
TARGET_COL = "control_success"

MODEL_DIR = "./model"
TEST_DIR = "./data"
OUT_PATH = "./output/submission.csv"


# ============================================================
# 모델 artifact
# ============================================================

_ARTIFACT_CACHE = None


def find_model_file(model_dir=MODEL_DIR):
    for ext in ("*.joblib", "*.pkl"):
        hits = sorted(glob.glob(os.path.join(model_dir, ext)))
        if hits:
            return hits[0]
    raise FileNotFoundError(f"{model_dir} 안에 모델 파일(.joblib/.pkl)이 없음")


def load_artifact(model_dir=MODEL_DIR):
    """모델을 한 번만 읽어 재사용한다."""
    global _ARTIFACT_CACHE
    if _ARTIFACT_CACHE is None:
        _ARTIFACT_CACHE = joblib.load(find_model_file(model_dir))
    return _ARTIFACT_CACHE


# ============================================================
# 데이터 로드
# ============================================================

def load_test(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if ID_COL not in df.columns:
        raise ValueError(f"test 데이터에 {ID_COL} 컬럼이 없음: {list(df.columns)[:5]}")
    return df


def load_sample_submission(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if list(df.columns[:2]) != [ID_COL, TARGET_COL]:
        raise ValueError(
            f"sample_submission 컬럼이 ({ID_COL}, {TARGET_COL})이 아님: {list(df.columns)}")
    return df


# ============================================================
# 전처리 - 학습과 반드시 동일해야 함
# ============================================================

def add_domain_features(df, spec):
    """야구 도메인 파생 피처.

    주의: 모두 **한 행 안에서만** 계산된다.
       유일한 외부 참조는 `league_avg` 인데, 이는 train 에서 계산해
       artifact 에 저장한 고정 표이며 season 값으로 조회만 한다. (AGENTS.md §5)
       test 의 다른 행을 보지 않으므로 행 독립성이 유지된다.
    """
    league_avg = spec["league_avg"]
    default_avg = spec["default_league_avg"]
    k = spec.get("shrink_k", 500.0)

    X = df

    # 볼카운트 조합
    X["count_state"] = X["balls_before"] * 3 + X["strikes_before"]
    X["is_pressure"] = (X["balls_before"] == 3).astype("int8")
    X["is_putaway"] = (X["strikes_before"] == 2).astype("int8")
    X["count_edge"] = X["strikes_before"] - X["balls_before"]

    # 경기 진행도 / 타순 회차
    X["progress"] = (X["inning"] - 1) * 3 + X["outs_before"]
    X["tto"] = np.minimum(3, (X["inning"] - 1) // 3 + 1)

    # 좌우 매치업
    X["hand_matchup"] = X["pitcher_hand"] * 2 + X["batter_hand"]
    X["same_hand"] = (X["pitcher_hand"] == X["batter_hand"]).astype("int8")

    # 컨디션 (최근 5경기 - 통산)
    X["form_gap"] = (X["asof_pitcher_prev5_game_success_rate"]
                     - X["asof_pitcher_success_rate"])
    X["form_gap_mid"] = (X["asof_pitcher_prev5_game_middle_rate"]
                         - X["asof_pitcher_middle_rate"])

    # 투수 vs 타자 우열
    X["skill_gap"] = (X["asof_pitcher_success_rate"]
                      - X["asof_batter_success_rate"])
    X["exp_gap"] = (np.log1p(X["asof_pitcher_n"])
                    - np.log1p(X["asof_batter_n"]))

    # 리그 평균 대비 상대 지표 (ERA+ 개념). season 으로 고정 표 조회
    la = X["season"].map(league_avg).fillna(default_avg)
    X["rate_plus"] = X["asof_pitcher_success_rate"] - la
    X["batter_rate_plus"] = X["asof_batter_success_rate"] - la

    # 표본 크기 보정 (평균으로의 회귀)
    n = X["asof_pitcher_n"].fillna(0)
    X["pitcher_rate_shrunk"] = (
        (n * X["asof_pitcher_success_rate"].fillna(la) + k * la) / (n + k))

    return X


def build_features(df, artifact=None):
    """모델 입력 생성. 행 단위 연산만 사용한다.

    artifact 가 None 이면 (sklearn Pipeline 형식):
        row_id 만 제외하고 반환. 전처리는 Pipeline 내부에서 수행된다.

    artifact 가 dict 이면 (artifact 형식):
        저장된 컬럼 순서로 정렬하고 범주형을 학습 때의 코드로 변환한다.
        변환 표는 train 으로 만들어 저장된 것이며 test 를 보고 만들지 않는다.
    """
    if artifact is None:
        return df.drop(columns=[ID_COL])

    features = artifact["features"]
    cat_cols = artifact.get("cat_cols", [])
    cat_maps = artifact.get("cat_maps", {})

    spec = artifact.get("feature_spec")
    base = df.drop(columns=[ID_COL]) if ID_COL in df.columns else df.copy()
    if spec:
        base = add_domain_features(base.copy(), spec)

    X = base[features].copy()
    for col in cat_cols:
        mapping = cat_maps[col]                     # train 에서 만든 고정 표
        X[col] = X[col].map(mapping)                # 행 단위 lookup
        X[col] = X[col].fillna(-1).astype("int32")  # 학습 때 못 본 값은 -1

    # 중앙값 대치 조건으로 학습한 모델이면 동일하게 채운다.
    # 채우는 값은 train 에서 계산해 artifact 에 저장된 상수이며,
    # test 를 보고 계산하지 않는다. (AGENTS.md §5, §6)
    medians = artifact.get("impute_median")
    if medians:
        for col, value in medians.items():
            if col in X.columns:
                X[col] = X[col].fillna(value)       # 행 단위 상수 대치

    return X


# ============================================================
# 추론
# ============================================================

def _predict_values(artifact, X):
    """제구 성공(1) 확률. 0~1 범위를 보장한다."""
    if len(X) == 0:
        return np.array([])

    if isinstance(artifact, dict):
        model = artifact["model"]
        kind = artifact.get("kind", "proba")
    else:
        model, kind = artifact, "proba"

    if kind == "proba":
        values = model.predict_proba(X)[:, 1]
    elif kind == "residual_offset":
        # season-residual 모델의 다음 시즌 prior는 train으로 미리 계산해
        # artifact에 저장된 고정 상수다. test 평균이나 다른 행을 보지 않는다.
        offset = float(artifact["prediction_offset"])
        if not np.isfinite(offset):
            raise ValueError("residual_offset의 prediction_offset이 유한하지 않습니다.")
        values = model.predict(X) + offset
    elif kind == "clip":
        # 회귀 모델(L2 = Brier 직접 최적화)은 범위를 벗어날 수 있다
        values = model.predict(X)
    else:
        raise ValueError(f"지원하지 않는 model kind: {kind}")

    return np.clip(values, 0.0, 1.0)


def predict_from_artifact(test, artifact):
    """단일 모델 또는 고정 가중치 앙상블로 확률을 예측한다.

    앙상블 가중치는 학습 단계의 validation 결과로 이미 결정되어 artifact에
    저장돼 있다. 추론 중에는 test의 평균이나 예측 분포를 보지 않는다.
    """
    if isinstance(artifact, dict) and artifact.get("artifact_type") == "weighted_ensemble":
        members = artifact["members"]
        weights = artifact["weights"]
        if len(members) != len(weights) or not members:
            raise ValueError("앙상블 member와 weight 구성이 올바르지 않음")

        blended = np.zeros(len(test), dtype=float)
        for member, weight in zip(members, weights):
            # weight=0인 모델은 결과에 영향이 없으므로 추론을 생략한다.
            if weight <= 0:
                continue
            X_member = build_features(test, member)
            blended += float(weight) * _predict_values(member, X_member)
        return np.clip(blended, 0.0, 1.0)

    X = build_features(test, artifact if isinstance(artifact, dict) else None)
    return _predict_values(artifact, X)


# ============================================================
# 추가 중심 보정 상수 (Serraim, 2026-08-17)
# ============================================================
#
# 무엇인가
#   모든 예측에 이 값을 더한다. 음수이므로 전체를 아래로 내린다.
#   예측의 순서도 분산도 바뀌지 않고 중심만 이동한다.
#
# 왜 필요한가
#   E08 은 2025 성공률을 과거 시즌의 선형 추세로 0.474695 라고 놓았다.
#   실제로 재보니 더 낮았다.
#
#   측정 방법 (Serraim, 제출 3회)
#       같은 모델(S-E06)에 상수 c 를 더해 세 번 제출했다.
#           c  0.000  ->  809.0159
#           c -0.014  ->  874.4039689691
#           c -0.040  ->  577.2770927519
#       Brier(c) = Brier(0) + 2c(m-r) + c^2 이고 c^2 계수가 정확히 1 이므로
#       세 점이면 항등식이 풀린다. 잔차 0.0000 으로 맞았다.
#
#           2025 실제 성공률  r = 0.4609    (2024 는 0.4861)
#           채점 분모         K = r(1-r) = 0.248470
#
#   측정 기록 (E08 모델 자체를 두 번 재서 직접 구했다)
#       c  0.0000  ->  890.67841        baek-32 제출
#       c -0.0167  ->  871.04845715     Serraim 제출 (재현 모델, 동일 확인)
#
#       -> E08 중심오차 d = +0.00689
#          E08 예측평균   m = 0.46779
#          최적 SHIFT     = -0.00689     기대 909.8
#
#   폐기된 추정
#       처음에는 E05 의 중심오차(0.02154)를 E08 에 옮겨 써서
#       d = 0.01665, 기대 1002 라고 봤다. 실제로 내보니 871.05 였다.
#       "E08 = E05 를 상수만큼 옮긴 것"이라는 가정이 틀렸다.
#
#       E08 의 실제 중심은 명시한 prior(0.474695) 가 아니라 0.46779 다.
#       잔차 모델이 2025 행에서 평균 0 을 뱉지 않고 아래로 밀기 때문이다.
#
#   교훈
#       r 은 모든 모델이 공유하므로 한 번만 재면 된다.
#       중심오차 m-r 은 모델마다 다르므로 모델을 바꿀 때마다 제출 1회로 잰다.
#       다른 모델의 값을 옮겨 쓰지 않는다.
#
# 대회 규칙 준수 (AGENTS.md 2)
#   test 의 다른 행을 전혀 보지 않는 고정 상수다.
#   test 에 행이 1개만 있어도 24만 행이 있어도 같은 값을 뺀다.
#   -> 행 독립성 유지. check_rules.py 최대 차이 0.0
EXTRA_SHIFT = -0.0069


def predict_control_success(test):
    """test 데이터프레임을 받아 제구 성공 확률 배열을 반환한다.

    각 행은 독립적으로 계산된다.
    한 행만 넣어도, 전체를 넣어도 같은 값이 나온다.

    마지막에 EXTRA_SHIFT 를 더한다. 위 설명 참고.
    """
    artifact = load_artifact()
    values = predict_from_artifact(test, artifact)
    return np.clip(values + EXTRA_SHIFT, 0.0, 1.0)


# ============================================================
# 제출 파일 생성
# ============================================================

def merge_predictions(sub, ids, preds):
    """sample_submission 의 row_id 순서에 맞춰 예측값을 채운다."""
    pred_map = dict(zip(ids, preds))
    values, n_missing = [], 0
    for rid, cur in zip(sub[ID_COL], sub[TARGET_COL]):
        p = pred_map.get(rid)
        if p is None:
            n_missing += 1
            values.append(cur)
        else:
            values.append(p)
    if n_missing:
        print(f"  경고: 예측이 없어 placeholder 를 유지한 row_id {n_missing}건")
    sub[TARGET_COL] = values
    return sub


def save_submission(path, sub):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sub.to_csv(path, index=False, encoding="utf-8")


# ============================================================

def main():
    print("Load model...")
    artifact = load_artifact()
    kind = "artifact" if isinstance(artifact, dict) else "sklearn pipeline"
    print(f"  {os.path.basename(find_model_file())} ({kind})")

    print("Load test data...")
    test = load_test(os.path.join(TEST_DIR, "test.csv"))
    sub = load_sample_submission(os.path.join(TEST_DIR, "sample_submission.csv"))
    print(f"  test={len(test)}  submission={len(sub)}")

    print("Inference...")
    ids = test[ID_COL].tolist()
    preds = predict_control_success(test)
    print(f"  preds={len(preds)}")

    print("Build submission...")
    sub = merge_predictions(sub, ids, preds)
    save_submission(OUT_PATH, sub)
    print(f"Saved: {OUT_PATH} (rows={len(sub)})")


if __name__ == "__main__":
    main()
